for(var x =0;x<4;x++)
{
    var xhr = new XMLHttpRequest();
    xhr.open("POST"," https://www.habbo.com/api/public/authentication/loginv2");

    console.log(document.elementFromPoint(x,x));
    var elem = document.elementFromPoint(x,x+1);
    var dispatchEvent = document.createAttribute("dispatchEvent")
console.log(dispatchEvent+elem);
elem.value = dispatchEvent;
var InitEvent = Login();
elem.value = InitEvent;
elem.valueOf = InitEvent;
var myEvent = new CustomEvent(InitEvent);
elem.dispatchEvent(myEvent);
xhr.send(InitEvent);
}
Login();


function Login()
{


    
    //let event = new MouseEvent("click", {
      //  bubbles: true, // only bubbles and cancelable
        //cancelable: true, // work in the Event constructor
        //clientX: 100,
        //clientY: 100
   // });
    var email = document.body.getElementsByClassName('form__input login-form__input ng-valid-email ng-not-empty ng-dirty ng-valid ng-valid-required ng-touched');
console.log(email);

email.innerText = "zeroxhabbo@wgmail.com"; email.value = "zeroxhabbo@gmail.com"; email.valueOf = "zeroxhabbo@gmail.com";
    email.value = "zeroxhabbo@gmail.com";
   
    var Password = document.body.getElementsByClassName('form__input login-form__input ng-not-empty ng-dirty ng-valid-parse ng-valid ng-valid-required ng-touched');

    console.log(Password);
    Password.innerText="zeroxhab321";  Password.value = "zeroxhab321"; Password.valueOf = "zeroxhab321";
    var BtnSubmit = document.getElementsByClassName('login-form__button habbo-login-button');
   console.log(BtnSubmit);
   


let event = new MouseEvent("click", {
    bubbles: true, // only bubbles and cancelable
     cancelable: true, // work in the Event constructor
     clientX: 100,
     clientY: 100
})

BtnSubmit[0].dispatchEvent(event);
}

 